# Blog Folder
This folder contains all blog posts in Markdown format.
